/**
 * Handle uniqueness error
 *
 * If the error is from a unique or required field - return the expected format using validation error
 */
const handleError = (error, req) => {
  // throw new ValidationError(
  //   [
  //     {
  //       field: field.name,
  //       message: req.t('error:valueMustBeUnique'),
  //     },
  //   ],
  //   req.t,
  // )
}

export default handleError
